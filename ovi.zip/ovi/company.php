<?php include 'head.php'; ?>




<section class="cta-section section-padding section-bg">
                <div class="container">
                    <div class="row justify-content-center align-items-center">

                        <div class="col-lg-12 col-12 ms-auto">
                            <h2 class="mb-0">

                            Ovijat food & beverage industries ltd is an emerging and growing international company in Bangladesh. Ovijat food & beverage industries ltd is a 100% export oriented company starts its journey in 2006. It is very honoring to get the knowledge that the owners of the company was auto rice businessman and it was the vision of Mr. Shamsul Haque to establish food unit that can ensure healthy life of the people around the world. Growth was considered as major Achievement of Mr. Shamsul Haque, Latter his dream was followed by his Elder son Mr. Mostafizur Rahman, Chairman of Ovijat food & beverage industries ltd.

Ovijat food believe food & beverage can help to live a healthy & hearty life and we ensure all the ingredients in our products which has a positive effect on the people health. Our Research and development(R & D) department are always working to reduce the portion of the ingredients that can affect your health.

Our commitment is to meet your daily health nutrition’s with our product and services.

Ovijat food & beverage has established many international office around the world to provide the best customer service to the clients and to make position in international market.

Ovijat has deep-rooted strong commercial alliances with its retail partners in Asia, Middle East, Europe and United States through ensuring quality product and growing reputations. The company has received ISO and HACCAP certification for its management and factories to ensure international standard.
                            </h2>
                    
                </div>
            </section>



<?php include 'foot.php'; ?>